﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PlayerCon : MonoBehaviour
{
    public bool grounded = false;
    [SerializeField] float HP = 2;
    public float speed;
    public float jumpHeight;
    float moveInput;
    float upInput;
    bool faceRight = true;
    Rigidbody2D rb;


    public float points;

    //refences the sprites to change at runtime
    public Sprite Armored;
    public Sprite NoArmor;

    //sets weapons
    public bool spear = true;
    public float WeaponSpeed;
    public float fastWeaponSpeed;
    public float Active_Weapons;
    public GameObject projectiles;

    //for weapon spawning
    public Rigidbody2D jav;
    public Rigidbody2D R_jav;
    public Rigidbody2D sword;
    public Rigidbody2D R_sword;
    public Transform SP;

    //animation stuff
    public Animator animator;

    //climbing
    private float inputVertical;
    public LayerMask Ladders;
    private bool isClimbing;
    public float cSpeed;
    public float distance;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        projectiles.GetComponent<projectile_script>();
        fastWeaponSpeed = WeaponSpeed + 150;
        
    }

    // Update is called once per frame
    void Update()
    {
        //basic movement *complete*
        moveInput = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);
        if (moveInput != 0)
        {
            animator.SetBool("isMoving", true);
        } else if (moveInput == 0)
        {
            animator.SetBool("isMoving", false);
        }

        if (grounded == true)
        {
            animator.SetBool("jumping", false);
        } else if (grounded == false)
        {
            animator.SetBool("jumping", true);
        }



        //turns the player *complete*
        if (faceRight == false && moveInput > 0)
        {
            turn();
        } else if (faceRight == true && moveInput < 0)
        {
            turn();
        }

        //jumping *complete*
        if (Input.GetButtonDown("Jump") && grounded == true)
        {
            rb.AddForce(new Vector2(0f, jumpHeight), ForceMode2D.Impulse);
        }

        //changes the sprite when the HP changes *complete*
        if (HP == 2)
        {
            animator.SetBool("injured", false);
            this.GetComponent<SpriteRenderer>().sprite = Armored;
        }
        if (HP == 1)
        {
            animator.SetBool("injured", true);
            this.GetComponent<SpriteRenderer>().sprite = NoArmor;
        }

        //throw weapon
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (spear == true)
            {
                if (faceRight == true)
                {
                    Rigidbody2D WeaponInstance;
                    WeaponInstance = Instantiate(jav, SP.position, SP.rotation);
                    WeaponInstance.AddForce(SP.right * WeaponSpeed);
                    Active_Weapons ++;
                } else if (faceRight == false)
                {
                    Rigidbody2D WeaponInstance;
                    WeaponInstance = Instantiate(R_jav, SP.position, SP.rotation);
                    WeaponInstance.AddForce(SP.right * -WeaponSpeed);
                    Active_Weapons++;
                }
            }
            else if (spear == false)
            {
                if (faceRight == true ) {
                    Rigidbody2D WeaponInstance;
                    WeaponInstance = Instantiate(sword, SP.position, SP.rotation);
                    WeaponInstance.AddForce(SP.right * fastWeaponSpeed);
                    Active_Weapons ++;
                } else if (faceRight == false)
                {
                    Rigidbody2D WeaponInstance;
                    WeaponInstance = Instantiate(R_sword, SP.position, SP.rotation);
                    WeaponInstance.AddForce(SP.right * -fastWeaponSpeed);
                    Active_Weapons ++;
                }
            }
        }

    }


    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.tag == "Ladder" && Input.GetKey(KeyCode.W) || other.tag == "Ladder" && Input.GetKey(KeyCode.UpArrow))
        {
            animator.SetBool("isClimbing", true);
            this.rb.velocity = new Vector2(rb.velocity.x, cSpeed);
        }
        else if (other.tag == "Ladder" && Input.GetKey(KeyCode.S) || other.tag =="Ladder" && Input.GetKey(KeyCode.DownArrow))
        {
            animator.SetBool("isClimbing", true);
            this.rb.velocity = new Vector2(rb.velocity.x, -cSpeed);
        }
        else
        {
            animator.SetBool("isClimbing", false);
            this.rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y);
        }
        
    }

  

    //reduce HP when the player collides with enimies
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "hostile")
        {
            HP = HP - 1;
            if (HP == 0)
            {
                //game over after hp = 0
                Loss();
            }
        }
    }


    //pickups and hostile projectiles
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Armor_PickUp")
        {
            HP = HP  + 1;
            Destroy(other.gameObject);
        } else if (other.gameObject.tag == "Money_PickUp")
        {
           points = points + 500;
            Destroy(other.gameObject);
        } else if (other.gameObject.tag == "Sword_PickUp")
        {
            spear = false;
            Destroy(other.gameObject);
        } else if (other.gameObject.tag == "Hostile_Projectile")
        {
            HP = HP - 1;
            Destroy(other.gameObject);
        }

    }



    //turns the player sprite when it changes direction *testing*
    void turn()
    {
        faceRight = !faceRight;
        Vector3 Scaler = transform.localScale;
        Scaler.x *= -1;
        transform.localScale = Scaler;
    }

    //loads the game over scene when HP = 0
    void Loss()
    {
        SceneManager.LoadScene("GameOver");
    }
}
