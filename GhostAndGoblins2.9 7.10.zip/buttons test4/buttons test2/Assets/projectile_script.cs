﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectile_script : MonoBehaviour
{
    private Rigidbody2D rb;
    public float Active_Weapons = 0;
    float Rng_Drops;
    public GameObject sword;
    public GameObject money;
    public GameObject armor;
    public Transform pos;


    // Start is called before the first frame update
    void Start()
    {
        Rng_Drops = Random.Range(0f, 10.0f);
        Active_Weapons++;
        rb = GetComponent<Rigidbody2D>();
        StartCoroutine(Waiting());
       
    }

    IEnumerator Waiting()
    {
        yield return new WaitForSeconds(3);
        Active_Weapons--;
        Destroy(this.gameObject);
    
    }

    // Update is called once per frame
    void Update()
    {
         pos = this.transform;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "hostile")
        {

            Active_Weapons--;
            Destroy(this.gameObject);
            /*
            if (Rng_Drops >= 0f && Rng_Drops < 4.0f)
            {
                Active_Weapons--;
                Destroy(this.gameObject);
            }
            if (Rng_Drops >= 4.0f && Rng_Drops < 6.0f)
            {
                //Rigidbody2D SwordInstance;
                Instantiate(sword, pos);
                Active_Weapons--;
                Destroy(this.gameObject);
            }
            if (Rng_Drops >= 6.0f && Rng_Drops < 8.0f)
            {
                //Rigidbody2D ArmorInstance;
              //  Instantiate(armor, pos);
                Active_Weapons--;
                Destroy(this.gameObject);
            }
            if (Rng_Drops >= 8.0f && Rng_Drops < 10.0f)
            {
                // Rigidbody2D MoneyInstance;
               // Instantiate(money, pos);
                Active_Weapons--;
                Destroy(this.gameObject);
            }*/
        }
    }
}
