﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting_Hostile : MonoBehaviour
{
    public GameObject Player;
    bool faceRight = true;
    public Rigidbody2D beam;
    public Rigidbody2D horBeam;
    float dropDelay;
    public float WeaponSpeed;
    public Transform SP;
    Rigidbody2D rb;
    public float moveSpeed;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        //points the hostile at the player when they start
        if (Player.transform.position.x < this.transform.position.x)
        {
            turn();
        }
    }

    //turns the enimy in the direction of the player *complete*
    void turn()
    {
        faceRight = !faceRight;
        Vector3 Scaler = transform.localScale;
        Scaler.x *= -1;
        transform.localScale = Scaler;
    }

    // Update is called once per frame
    void Update()
    {

        if (faceRight == false)
        {
            rb.velocity = new Vector2(-moveSpeed, rb.velocity.y);
        }
        else if (faceRight == true)
        {
            rb.velocity = new Vector2(moveSpeed, rb.velocity.y);
        }

        if (Player.transform.position.y < this.transform.position.y && Player.transform.position.x == this.transform.position.x)
            {
            Rigidbody2D GhostAttack;
            GhostAttack = Instantiate(beam, SP.position, SP.rotation);
            GhostAttack.AddForce(SP.up * -WeaponSpeed);
            }
        
            if (dropDelay > 0)
        {
            dropDelay -= Time.deltaTime;
        }
            else
        {
            Rigidbody2D GhostAttack;
            GhostAttack = Instantiate(beam, SP.position, SP.rotation);
            GhostAttack.AddForce(SP.up * -WeaponSpeed);
            dropDelay = Random.Range(1.0f, 5.0f);
        }
        
    }

    

    // disables collider temporarally when hits the player *complete*
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            StartCoroutine(Waiting());
        }
    }

    //disables collisions 
    IEnumerator Waiting()
    {
        GetComponent<BoxCollider2D>().enabled = false;
        yield return new WaitForSeconds(3);
        GetComponent<BoxCollider2D>().enabled = true;
    }


    //destroys when hit with weapon
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "projectile")
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.tag == "hostileArea")
        {
            turn();
            if(faceRight == true)
            {
                rb.transform.position = new Vector2(rb.transform.position.x, rb.transform.position.y - (rb.transform.position.y *.1f));
                rb.velocity = new Vector2(-moveSpeed, rb.velocity.y);
            }  else if(faceRight == false)
            {
                rb.velocity = new Vector2(moveSpeed, rb.velocity.y);
            }

        }
    }
}


